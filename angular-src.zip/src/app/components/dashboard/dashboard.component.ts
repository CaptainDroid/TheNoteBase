import { Component, OnInit } from '@angular/core';
import { AuthService } from '../../services/auth.service';
import { FlashMessagesService } from 'angular2-flash-messages';
import {ReversePipe} from '../../pipes/reverse';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css'],
  
})
export class DashboardComponent implements OnInit {
 //questions: questions[];
 questions: Array<Object>;
  //questions: String;
  query:'';
  author: author[];
  constructor(private authService: AuthService, private flashMessage: FlashMessagesService) { 
  }

  ngOnInit() {
   this.authService.fetchQuestions().subscribe(questions => {
      this.questions=JSON.parse(JSON.stringify(questions));
      console.log(this.questions);
    
    });
    console.log(this.questions);
}
}

/*interface questions{
  question: string;
  _id: string;
  author:{
    id: string;
    name: string;
    email:string;
    username: string;
    branch: string;
    stuFac: string;
  }
  //author: Object;
}*/

interface author{
  
    id: string;
    name: string;
    username: string;
    email:string;
    branch: string;
    stuFac: string;
  
}