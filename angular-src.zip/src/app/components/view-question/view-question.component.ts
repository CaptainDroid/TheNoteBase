import { Component, OnInit } from '@angular/core';
import { AuthService } from '../../services/auth.service';
import { FlashMessagesService } from 'angular2-flash-messages';
import { Router, ActivatedRoute } from '@angular/router';
import { ValidateService} from '../../services/validate.service';
@Component({
  selector: 'app-view-question',
  templateUrl: './view-question.component.html',
  styleUrls: ['./view-question.component.css']
})
export class ViewQuestionComponent implements OnInit {
 // questionName: Array<Object>;
 questionName: Object;
  questionid: String;
  answerer: Object;
  queAnswer: Array<Object>;
  answer:String;
  constructor(
    private authService: AuthService,
    private flashMessage: FlashMessagesService,
    private router:Router,
    private route: ActivatedRoute,
    private validateService: ValidateService) { }

  ngOnInit() {
    this.route.params.subscribe(params => {
      this.questionid=params['id'];
    });
    console.log(this.questionid);
    this.authService.getQuestion(this.questionid).subscribe(question => {
      //this.questionName=JSON.parse(JSON.stringify(question));
      this.questionName=question;
      console.log(this.questionName);
});

this.authService.getAnswers(this.questionid).subscribe(answers => {
    this.queAnswer= JSON.parse(JSON.stringify(answers));
    console.log(this.queAnswer);
});
  }

  

  onAnswerSubmit(){

     const newAnswer={
       questionid:this.questionid,
      answer:this.answer,
      answerer:this.authService.loadUser()
  };
    console.log(newAnswer.questionid);
    console.log(newAnswer.answerer);
    if(!this.validateService.validateAnswer(newAnswer)){
      this.flashMessage.show("Answer field is empty. Please enter the answer to post.",{
        cssClass:"alert-danger", timeout: 3000
      });
      return false;
    }
    
   this.authService.answerQuestion(newAnswer).subscribe(data => {
      if(data.success){
        this.flashMessage.show("Your answer has been successfully posted", {
          cssClass:"alert-success", timeout:3000
        });
        this.router.navigate(['/dashboard']);
      }
      else{
        this.flashMessage.show("Something went wrong while posting your answer. Please try again.",{
          cssClass:"alert-danger", timeout:3000
        });
      }
    });
  }

  onUpvote(answer){
    console.log("onupvote called");
    
    if((answer.answerer.username == this.authService.loadUser().username)||(answer.answerer.name == this.authService.loadUser().username))
    {
      this.flashMessage.show("You cannot upvote your own answer", {
        cssClass:"alert-danger", timeout:3000
      });
    }
    else{
            this.authService.upvote(answer).subscribe(data => {
              if(data.success){
                this.flashMessage.show("Your upvoted this answer.", {
                  cssClass:"alert-success", timeout:3000
                });
              }
              else{
                this.flashMessage.show("Something went wrong.",{
                  cssClass:"alert-danger", timeout:3000
                });
              }
            });
    }
  }


}



interface answerer{
  username: string;
  userid: string;
  branch: string;
  stuFac: string;
  answer: string;
  email: string;
}