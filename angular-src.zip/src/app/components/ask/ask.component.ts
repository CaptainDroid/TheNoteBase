import { Component, OnInit } from '@angular/core';
import {ValidateService} from '../../services/validate.service';
import {AuthService} from '../../services/auth.service';
import {FlashMessagesService} from 'angular2-flash-messages';
import {Router} from '@angular/router';

@Component({
  selector: 'app-ask',
  templateUrl: './ask.component.html',
  styleUrls: ['./ask.component.css'],
  })
export class AskComponent implements OnInit {
  question: String;
  author: Object;
  constructor(
    private validateService: ValidateService,
    private flashMessage: FlashMessagesService,
    private authService: AuthService,
    private router: Router,
  ) { }

  ngOnInit() {
  }
  onAskSubmit(){
    
    const newQuestion={
      question:this.question,
      author:this.authService.loadUser()
  }
    console.log(newQuestion);
    console.log(newQuestion.author.email);
    console.log(newQuestion.author.stuFac);
    //Validate question not being empty
    if(!this.validateService.validateQuestion(newQuestion)){
      this.flashMessage.show("Question field is empty. Please enter the question to ask.",{
        cssClass:"alert-danger", timeout: 3000
      });
      return false;
    }
    
    this.authService.askQuestion(newQuestion).subscribe(data => {
      if(data.success){
        this.flashMessage.show("Your question has been successfully posted", {
          cssClass:"alert-success", timeout:3000
        });
        this.router.navigate(['/dashboard']);
      }
      else{
        this.flashMessage.show("Something went wrong while posting your question. Please try again.",{
          cssClass:"alert-danger", timeout:3000
        });
        this.router.navigate(['/dashboard']);
      }
    });
    
  }

}
