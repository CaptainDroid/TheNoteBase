import { Injectable } from '@angular/core';
import {Http, Headers, RequestOptions, URLSearchParams} from '@angular/http';
import 'rxjs/add/operator/map';
import {tokenNotExpired} from 'angular2-jwt';

@Injectable()
export class AuthService {
authToken: any;
user: any;

  constructor(private http: Http) { }
//REGISTER USER
  registerUser(user)
  {
    let headers= new Headers();
    headers.append('Content-Type','application/json');
    return this.http.post('users/register', user, {headers:headers})
      .map( res => res.json());
  }


//AUTHENTICATE USER
  authenticateUser(user){
    let headers= new Headers();
    headers.append('Content-Type', 'application/json');
    return this.http.post('users/authenticate', user, {headers:headers})
      .map( res=> res.json());
  }


//LOAD USER PROFILE INFORMATION
  getProfile(){
    let headers= new Headers();
    this.loadToken();
    headers.append('Authorization',this.authToken);
    headers.append('Content-Type', 'application/json');
    return this.http.get('users/profile', {headers:headers})
      .map( res=> res.json());
  }


  //LOAD TOKEN FOR AUTHORIZATION CHECK
  loadToken(){
    this.authToken= localStorage.getItem('token'); //LATEST UPDATE changed from 'id_token' to 'token' since latest angular commit changed tokenNotExpired function to accept toke instead of id_token
  }


  //LOADING USER FOR RELATING USER INFO WITH QUESTIONS ASKED
  loadUser(){
    return JSON.parse(localStorage.getItem('user'));
  }


  //CHECKING IF TOKEN OF USER EXPIRED OR NOT
  loggedIn(){
   
    return tokenNotExpired();//LATEST UPDATE- You dont have to pass the parameter name 'id_token' in this function if change id_token to token according to "LATEST UPDATE" comments in getItem and setItem
  }

  //STORE USER DATA IN LOCAL STORAGE
  storeUserData(token, user){
    localStorage.setItem('token', token);//LATEST UPDATE changed from 'id_token' to 'token' since latest angular commit changed tokenNotExpired function to accept toke instead of id_token
    localStorage.setItem('user', JSON.stringify(user));//JSON.stringify because localstorage can only store strings, not objects, so user needs to be converted to string to be stored, and it is parsed back in to json when fetched back from local storage
    this.authToken= token;
    this.user= user;
  }


  //POST QUESTIONS
  askQuestion(newQuestion){
    let headers= new Headers();
    headers.append('Content-Type', 'application/json');
    return this.http.post('users/ask', newQuestion, {headers:headers})
      .map( res => res.json());
  }

  //ANSWER USER QUESTION
  answerQuestion(newAnswer){
    let headers= new Headers();
    headers.append('Content-Type', 'application/json');
    return this.http.post('users/answer', newAnswer, {headers:headers})
      .map( res => res.json());
  }


  //FETCH QUESTIONS FROM DATABASE FOR USERS' DASHBOARD
 fetchQuestions(){
    let headers=new Headers();
    headers.append('Content-Type', 'appication/json');
   // let myParams = new URLSearchParams()
    //myParams.append('query', query);
    //let options = new RequestOptions({headers:headers, search:myParams});
    console.log("calling fetchQuestions");
    return this.http.get('users/fetch', {headers:headers})//pass options in place of headers to send query
      .map(res => res.json());
  }
  

  // FETCH ANSWERS FOR QUESTIONS
   //FETCH QUESTIONS FROM DATABASE FOR USERS' DASHBOARD
 fetchAnswers(query){
    let headers=new Headers();
    headers.append('Content-Type', 'appication/json');
   // let myParams = new URLSearchParams()
    //myParams.append('query', query);
    //let options = new RequestOptions({headers:headers, search:myParams});
    console.log("calling fetchQuestions");
    return this.http.get('users/answer', {headers:headers})//pass options in place of headers to send query
      .map(res => res.json());
  }


  //GET QUESTION BY ID
  getQuestion(questionid){
    let headers=new Headers();
    headers.append('Content-Type', 'appication/json');
   let myParams = new URLSearchParams()
    myParams.append('query', questionid);
    let options = new RequestOptions({headers:headers, search:myParams});
    console.log("calling fetchQuestions");
    return this.http.get('users/retrieveQuestionById/'+ questionid,options)
      .map(res => res.json());
  }

  // GET ANSWERS BY QUESTION ID
  getAnswers(questionid){
    let headers=new Headers();
    headers.append('Content-Type', 'appication/json');
   let myParams = new URLSearchParams()
    myParams.append('query', questionid);
    let options = new RequestOptions({headers:headers, search:myParams});
    console.log("calling fetchQuestions");
    return this.http.get('users/retrieveAnswerById/'+ questionid,options)
      .map(res => res.json());
  
  }


  //LOG OUT OF THE PLATFORM
  logout(){
    this.authToken=null;
    this.user=null;
    localStorage.clear();
  }


  //UPVOTE
  upvote(answer){
    let headers= new Headers();
    headers.append('Content-Type', 'application/json');
    return this.http.post('users/upvote', answer, {headers:headers})
      .map( res => res.json());
  }


}
